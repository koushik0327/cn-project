"""
Signal Processor Module for Wi-Fi Monitoring System
Provides RSSI signal filtering (Kalman & Moving Average),
Log-Distance Path Loss distance estimation, Shannon-Hartley Capacity estimation,
Z-Score signal anomaly detection, and linear trend prediction (Time-To-Disconnection).
"""

import math
import statistics

class KalmanFilter:
    """
    1D Kalman Filter for smoothing noisy RSSI telemetry stream.
    """
    def __init__(self, process_noise=0.008, measurement_noise=0.8, initial_value=-60.0):
        self.q = process_noise  # Process noise covariance
        self.r = measurement_noise  # Measurement noise covariance
        self.x = float(initial_value)  # Estimated state
        self.p = 1.0  # Estimation error covariance

    def update(self, measurement: float) -> float:
        self.p = self.p + self.q
        k = self.p / (self.p + self.r)
        self.x = self.x + k * (measurement - self.x)
        self.p = (1 - k) * self.p
        return round(self.x, 2)


class MovingAverageFilter:
    """
    Simple Moving Average (SMA) filter over a sliding window.
    """
    def __init__(self, window_size=5):
        self.window_size = window_size
        self.buffer = []

    def update(self, measurement: float) -> float:
        self.buffer.append(measurement)
        if len(self.buffer) > self.window_size:
            self.buffer.pop(0)
        return round(sum(self.buffer) / len(self.buffer), 2)


class PathLossEstimator:
    """
    Estimates physical distance (in meters) to the Access Point
    using the Log-Distance Path Loss Model:
    RSSI(d) = RSSI_0 - 10 * n * log10(d / d_0) + X_sigma
    => d = d_0 * 10 ^ ((RSSI_0 - RSSI) / (10 * n))
    """
    def __init__(self, reference_rssi=-40.0, reference_distance=1.0, path_loss_exponent=2.8):
        self.rssi_0 = reference_rssi
        self.d_0 = reference_distance
        self.n = path_loss_exponent

    def calculate_distance(self, rssi: float) -> float:
        if rssi >= 0:
            return 0.1
        try:
            exponent = (self.rssi_0 - rssi) / (10.0 * self.n)
            distance = self.d_0 * math.pow(10, exponent)
            return round(max(0.1, distance), 2)
        except Exception:
            return 0.0


class ShannonCapacityCalculator:
    """
    Calculates theoretical maximum channel throughput (in Mbps)
    using the Shannon-Hartley Theorem:
    C = B * log2(1 + SNR)
    SNR_linear = 10 ^ ((RSSI_dBm - NoiseFloor_dBm) / 10)
    """
    @staticmethod
    def calculate_capacity(rssi_dbm: float, noise_floor_dbm: float = -95.0, bandwidth_mhz: float = 20.0) -> float:
        try:
            snr_db = max(0.1, rssi_dbm - noise_floor_dbm)
            snr_linear = math.pow(10, snr_db / 10.0)
            capacity_bps = (bandwidth_mhz * 1e6) * math.log2(1.0 + snr_linear)
            capacity_mbps = capacity_bps / 1e6
            return round(capacity_mbps, 2)
        except Exception:
            return 0.0


class ZScoreAnomalyDetector:
    """
    Detects sudden statistical signal anomalies (drops > 2.5 standard deviations)
    distinguishing rapid environmental fading from steady distance decay.
    """
    def __init__(self, window_size=20, threshold_z=2.5):
        self.window_size = window_size
        self.threshold_z = threshold_z
        self.history = []

    def update(self, rssi: float) -> dict:
        if len(self.history) < 5:
            self.history.append(rssi)
            return {"is_anomaly": False, "z_score": 0.0, "severity": "NORMAL"}

        mean = statistics.mean(self.history)
        stdev = statistics.stdev(self.history) if len(self.history) > 1 else 0.001
        if stdev < 0.001:
            stdev = 0.001

        z_score = (rssi - mean) / stdev
        is_anomaly = z_score < -self.threshold_z

        self.history.append(rssi)
        if len(self.history) > self.window_size:
            self.history.pop(0)

        severity = "NORMAL"
        if z_score < -3.5:
            severity = "CRITICAL_DROP"
        elif z_score < -2.5:
            severity = "MODERATE_DROP"

        return {
            "is_anomaly": is_anomaly,
            "z_score": round(z_score, 2),
            "severity": severity
        }


class SignalTrendPredictor:
    """
    Calculates signal trajectory slope (dBm/sec) over rolling time window
    and estimates Time-To-Disconnection (TTD) in seconds before reaching -90 dBm limit.
    """
    def __init__(self, window_size=15):
        self.window_size = window_size
        self.history = []

    def update(self, rssi: float) -> dict:
        self.history.append(rssi)
        if len(self.history) > self.window_size:
            self.history.pop(0)

        n = len(self.history)
        if n < 3:
            return {"slope_dbm_per_sec": 0.0, "ttd_seconds": None, "trend": "STABLE"}

        # Linear regression: slope m = (n*sum(xy) - sum(x)sum(y)) / (n*sum(x^2) - (sum(x))^2)
        x_vals = list(range(n))
        y_vals = self.history

        sum_x = sum(x_vals)
        sum_y = sum(y_vals)
        sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
        sum_x2 = sum(x ** 2 for x in x_vals)

        denom = (n * sum_x2 - sum_x ** 2)
        slope = (n * sum_xy - sum_x * sum_y) / denom if denom != 0 else 0.0
        slope = round(slope, 3)

        ttd_seconds = None
        trend = "STABLE"

        if slope < -0.15:
            trend = "DEGRADATING"
            remaining_dbm = rssi - (-90.0)
            if remaining_dbm > 0 and abs(slope) > 0.01:
                ttd_seconds = round(remaining_dbm / abs(slope), 1)
        elif slope > 0.15:
            trend = "IMPROVING"

        return {
            "slope_dbm_per_sec": slope,
            "ttd_seconds": ttd_seconds,
            "trend": trend
        }


class SignalQualityEvaluator:
    """
    Evaluates Wi-Fi signal quality, percentage strength, and alert status based on RSSI values.
    """
    @staticmethod
    def get_quality_metrics(rssi: float):
        if rssi >= -50:
            rating = "Excellent"
            color = "#10b981"
            recommendation = "Ideal for 4K Streaming, Gaming & VoIP"
        elif rssi >= -65:
            rating = "Good"
            color = "#06b6d4"
            recommendation = "Reliable HD Video Calls & Fast Downloads"
        elif rssi >= -75:
            rating = "Fair"
            color = "#f59e0b"
            recommendation = "Basic Web Browsing & Text Messaging"
        elif rssi >= -90:
            rating = "Weak"
            color = "#ef4444"
            recommendation = "High Packet Loss Expected - Relocate Closer to AP"
        else:
            rating = "Disconnected"
            color = "#6b7280"
            recommendation = "No Reliable Signal Detected"

        calculated_percentage = max(0, min(100, int(2 * (rssi + 100))))
        is_critical = rssi < -75.0

        return {
            "rating": rating,
            "color": color,
            "recommendation": recommendation,
            "percentage": calculated_percentage,
            "is_critical": is_critical
        }
