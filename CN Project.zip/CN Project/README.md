# Wi-Fi Signal Strength Monitoring System
### Using Real-Time RSSI Analysis & Network Diagnostics

**Computer Networks B.Tech Project**  
**100% Free & Open-Source Implementation**

---

## 👥 Student Team Details

- **Student 1**: Anuprakash Dubey (Reg No: `23BDS0162`, Branch: *B.Tech Computer Science & Engineering*)
- **Student 2**: C. Koushik Kumar (Reg No: `24BCE2320`, Branch: *B.Tech Computer Science & Engineering*)
- **Student 3**: A. Roohan Prakaash (Reg No: `23BCE0209`, Branch: *B.Tech Computer Science & Engineering*)

---

## 📌 Executive Abstract & Project Overview

Wireless 802.11 Local Area Networks frequently experience signal attenuation, dead zones, and co-channel interference due to physical barriers, distance, and environmental noise.

This project develops an automated real-time **Wi-Fi Signal Strength Monitoring System** based on continuous RSSI (Received Signal Strength Indicator) sampling.

The system captures RSSI telemetry in decibel-milliwatts (dBm), evaluates wireless link quality, logs historical performance into an SQLite relational database, and dynamically flags weak signal zones. It provides network administrators and end-users with an intuitive graphical web dashboard displaying real-time signal fluctuations, path-loss distance estimations, spatial coverage heatmaps, automated threshold audio/visual alerts, and ping latency diagnostics.

### ⚡ Key Metric: RSSI (dBm) Scale
| RSSI Range (dBm) | Quality Rating | Recommended Usage |
|---|---|---|
| **-30 to -50 dBm** | Excellent Signal | Ideal / Max Speed / 4K Streaming |
| **-50 to -65 dBm** | Good Signal | Reliable HD Video Calling & Downloads |
| **-65 to -75 dBm** | Fair Signal | Basic Web Browsing |
| **-75 to -90 dBm** | Weak Signal | High Packet Loss / Dropouts Expected |
| **Below -90 dBm** | No Service | Disconnected |

---

## 🏗️ System Architecture & Layered Design

```
+-----------------------------------------------------------------------+
| LAYER 1: DATA ACQUISITION                                            |
| Wi-Fi Adapter (802.11) --> netsh / nmcli / OS Telemetry Scanner       |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| LAYER 2: PROCESSING & NOISE FILTERING                                |
| RSSI Collector --> 1D Kalman Filter --> Log-Distance Path Loss Model  |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| LAYER 3: PERSISTENCE & ANALYTICS                                      |
| Relational SQLite DB (wifi_monitor.db) --> Historical Logs & CSV     |
+-----------------------------------------------------------------------+
                                  |
                                  v
+-----------------------------------------------------------------------+
| LAYER 4: PRESENTATION & ALERTING                                      |
| Real-Time Web Dashboard --> Live Chart.js --> Heatmap --> Beep Alert |
+-----------------------------------------------------------------------+
```

---

## 🧮 Mathematical Models

### 1. Log-Distance Path Loss Model
Distance estimation (in meters) to the Access Point is computed using:
$$d = d_0 \cdot 10^{\frac{RSSI_0 - RSSI}{10 \cdot n}}$$

where:
- $RSSI_0$: Signal strength at reference distance $d_0 = 1.0\text{m}$ (default $-40.0\text{ dBm}$)
- $n$: Path loss exponent ($2.0$ for free space, $2.7 - 3.5$ for obstructed indoor walls)

### 2. One-Dimensional Kalman Filter
Raw RSSI data streams contain multipath fading noise. The Kalman filter smoothes variations via:
$$\hat{x}_k = \hat{x}_{k-1} + K_k \cdot (z_k - \hat{x}_{k-1})$$
$$K_k = \frac{P_{k-1} + Q}{P_{k-1} + Q + R}$$

---

## 📚 IEEE & Academic Literature Survey Summary

1. **RADAR: In-Building RF Location System** (*Pahlavan & Padmanabhan, 2000*) — Empirical RSSI fingerprinting.
2. **Indoor Path Loss Models for 2.4/5GHz** (*Rappaport et al., 2002*) — Log-normal shadowing model ($n = 2.0$ to $4.5$).
3. **WLAN Channel Interference Analysis** (*Mishra et al., 2006*) — Channel overlap throughput degradation.
4. **Large-Scale WLAN Campus Design** (*Hills & Johnson, 2001*) — Minimum -67 dBm boundary for VoIP.
5. **Wireless Channel Fading & Shadowing** (*Goldsmith & Joo, 2005*) — Rayleigh/Rician fading models.
6. **Enterprise WLAN Architecture** (*Cisco Systems, 2018*) — Transmit power control.
7. **Real-time RSSI Filtering via Kalman** (*Zhou & Wang, 2020*) — EKF smoothing reduces variance noise by 65%.
8. **RSSI-based Indoor Localization Survey** (*Al-Ammar et al., 2014*) — Comparative survey of trilateration vs fingerprinting.
9. **Multi-AP Wi-Fi Coverage Heatmapping** (*Kumar & Sharma, 2022*) — IDW spatial interpolation visual heatmaps.
10. **Lightweight Wi-Fi Anomaly Detection** (*Zhang & Liu, 2023*) — Threshold-based anomaly detection on client telemetry.

---

## 🚀 Key Features

1. **Continuous 1-Second Sampling**: Real-time RSSI extraction via OS interfaces (`netsh wlan` on Windows, `nmcli` on Linux) with adaptive synthetic fallback for non-Wi-Fi environments.
2. **Kalman & SMA Signal Filtering**: Dual-stream line chart plotting raw vs. smoothed RSSI telemetry without dropping GUI frames.
3. **Log-Distance Distance Estimator**: Computes distance to Access Point dynamically in meters.
4. **Spatial Floorplan Coverage Heatmap**: Interactive 2D canvas visualizer allowing spatial sampling and dead zone mapping.
5. **Automated Alert Engine**: Triggers popups and synthesized Web Audio warning beeps when RSSI drops below threshold (default $-75.0\text{ dBm}$).
6. **Network Ping Diagnostics**: Tests RTT latency, jitter (variance), and packet loss percentage against target hosts.
7. **SQLite Database Persistence & CSV Export**: Complete historical audit trail and CSV download capabilities.

---

## 🛠️ Installation & Usage Guide

### Prerequisites
- Python 3.8 or higher installed.
- No paid software or API keys required (100% free and open-source).

### Quick Start (Windows)
Double-click `run.bat` or run:
```cmd
pip install -r requirements.txt
python app.py
```

### Quick Start (Linux / macOS)
```bash
chmod +x run.sh
./run.sh
```

Then open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🧪 Automated System Tests
To run unit and integration tests:
```bash
python test_system.py
```
