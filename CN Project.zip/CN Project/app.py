"""
Main Flask Web Application Server & REST API
Wi-Fi Signal Strength Monitoring System (Advanced Academic Edition)
"""

import os
from flask import Flask, jsonify, request, send_from_directory, Response
from flask_cors import CORS

from scanner import WiFiScanner
from signal_processor import (
    KalmanFilter, MovingAverageFilter, PathLossEstimator,
    SignalQualityEvaluator, ShannonCapacityCalculator,
    ZScoreAnomalyDetector, SignalTrendPredictor
)
from database import DatabaseManager
from diagnostics import NetworkDiagnostics
from heatmap_engine import IDWInterpolationEngine, MultiAPRoamingSimulator

app = Flask(__name__, static_folder="static", static_url_path="")
CORS(app)

# Core Processor & Engine Instances
db = DatabaseManager()
scanner = WiFiScanner(mode="hardware")
kalman = KalmanFilter(process_noise=0.008, measurement_noise=0.8)
sma = MovingAverageFilter(window_size=5)
path_loss = PathLossEstimator(reference_rssi=-40.0, reference_distance=1.0, path_loss_exponent=2.8)
z_detector = ZScoreAnomalyDetector(window_size=20, threshold_z=2.5)
trend_predictor = SignalTrendPredictor(window_size=15)
diag = NetworkDiagnostics()
idw_engine = IDWInterpolationEngine(power=2.0)
multi_ap_sim = MultiAPRoamingSimulator(reference_rssi=-35.0, path_loss_exponent=2.8)

# Application Settings
config_state = {
    "alert_threshold": -75.0,
    "path_loss_exponent": 2.8,
    "channel_bandwidth_mhz": 20.0,
    "scan_interval_ms": 1000
}

@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/api/telemetry", methods=["GET"])
def get_telemetry():
    """
    Continuous 1-second telemetry sampling endpoint.
    Processes raw RSSI, applies Kalman/SMA filters, calculates Shannon Capacity,
    evaluates Z-Score anomalies, predicts signal trends (TTD), and logs to SQLite.
    """
    raw_data = scanner.scan()
    raw_rssi = raw_data.get("rssi", -100.0)
    is_connected = raw_data.get("connected", False)

    if not is_connected:
        kalman_rssi = -100.0
        sma_rssi = -100.0
        estimated_distance = 0.0
        shannon_capacity = 0.0
        quality = {
            "rating": "Disconnected",
            "color": "#6b7280",
            "recommendation": "Wi-Fi Interface is Disconnected or Turned OFF",
            "percentage": 0,
            "is_critical": True
        }
        anomaly_status = {"is_anomaly": False, "z_score": 0.0, "severity": "DISCONNECTED"}
        trend_status = {"slope_dbm_per_sec": 0.0, "ttd_seconds": None, "trend": "DISCONNECTED"}
        is_critical = True
        alert_triggered = True
    else:
        # Process signal filters
        kalman_rssi = kalman.update(raw_rssi)
        sma_rssi = sma.update(raw_rssi)

        # Calculate Log-Distance Path Loss
        path_loss.n = config_state["path_loss_exponent"]
        estimated_distance = path_loss.calculate_distance(kalman_rssi)

        # Calculate Shannon-Hartley Theoretical Capacity (Mbps)
        noise_floor = raw_data.get("noise_floor", -95.0)
        bandwidth = config_state["channel_bandwidth_mhz"]
        shannon_capacity = ShannonCapacityCalculator.calculate_capacity(kalman_rssi, noise_floor, bandwidth)

        # Z-Score Anomaly Detection
        anomaly_status = z_detector.update(raw_rssi)

        # Signal Trend & Time-To-Disconnection Prediction
        trend_status = trend_predictor.update(kalman_rssi)

        # Evaluate link quality metrics
        quality = SignalQualityEvaluator.get_quality_metrics(kalman_rssi)
        
        # Check alert threshold
        is_critical = kalman_rssi < config_state["alert_threshold"] or anomaly_status["is_anomaly"]
        alert_triggered = False

        if is_critical:
            msg = f"RSSI: {kalman_rssi} dBm (Z-Score: {anomaly_status['z_score']}, Severity: {anomaly_status['severity']})"
            db.log_alert(
                event_type="WEAK_SIGNAL" if kalman_rssi < config_state["alert_threshold"] else "ANOMALY_DROP",
                rssi=kalman_rssi,
                message=msg,
                status="WARNING"
            )
            alert_triggered = True

    # Build comprehensive telemetry record
    record = {
        "is_connected": is_connected,
        "ssid": raw_data.get("ssid", "Wi-Fi Disconnected"),
        "bssid": raw_data.get("bssid", "00:00:00:00:00:00"),
        "raw_rssi": raw_rssi if is_connected else -100.0,
        "kalman_rssi": kalman_rssi,
        "sma_rssi": sma_rssi,
        "signal_percent": raw_data.get("signal_percent", 0),
        "estimated_distance": estimated_distance,
        "shannon_capacity_mbps": shannon_capacity,
        "anomaly": anomaly_status,
        "trend": trend_status,
        "rating": quality["rating"],
        "rating_color": quality["color"],
        "recommendation": quality["recommendation"],
        "channel": raw_data.get("channel", 0),
        "frequency": raw_data.get("frequency", "N/A"),
        "radio_type": raw_data.get("radio_type", "N/A"),
        "rx_rate": raw_data.get("rx_rate", "0 Mbps"),
        "tx_rate": raw_data.get("tx_rate", "0 Mbps"),
        "noise_floor": raw_data.get("noise_floor", -95.0),
        "is_critical": is_critical,
        "alert_triggered": alert_triggered,
        "is_simulated": raw_data.get("is_simulated", False)
    }

    # Log to SQLite DB if connected
    if is_connected:
        db.log_telemetry(record)

    return jsonify(record)

@app.route("/api/mode", methods=["POST"])
def set_scanner_mode():
    data = request.json or {}
    new_mode = data.get("mode", "hardware")
    scanner.set_mode(new_mode)
    return jsonify({"status": "success", "mode": new_mode})

@app.route("/api/history", methods=["GET"])
def get_history():
    limit = request.args.get("limit", default=60, type=int)
    history = db.get_recent_telemetry(limit=limit)
    return jsonify(history)

@app.route("/api/analytics", methods=["GET"])
def get_analytics():
    summary = db.get_analytics_summary()
    return jsonify(summary)

@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    limit = request.args.get("limit", default=30, type=int)
    alerts = db.get_all_alerts(limit=limit)
    return jsonify(alerts)

@app.route("/api/diagnostics/ping", methods=["POST"])
def run_ping_diagnostics():
    data = request.json or {}
    target = data.get("target", "8.8.8.8")
    count = data.get("count", 4)
    result = diag.run_ping_test(host=target, count=count)
    
    db.log_diagnostic(
        target=result["host"],
        latency=result["avg_latency_ms"],
        jitter=result["jitter_ms"],
        loss=result["packet_loss_pct"],
        status=result["status"]
    )
    return jsonify(result)

@app.route("/api/diagnostics/multi-ping", methods=["GET", "POST"])
def run_multi_ping():
    hosts = ["8.8.8.8", "1.1.1.1", "208.67.222.222"]
    if request.json and "hosts" in request.json:
        hosts = request.json["hosts"]
    results = diag.run_multi_ping_matrix(hosts=hosts, count=3)
    return jsonify(results)

@app.route("/api/heatmap", methods=["GET", "POST"])
def handle_heatmap():
    if request.method == "POST":
        data = request.json or {}
        label = data.get("label", "Point A")
        x = float(data.get("x", 0))
        y = float(data.get("y", 0))
        rssi = float(data.get("rssi", -60))
        dist = float(data.get("distance", 2.0))
        db.save_heatmap_sample(label, x, y, rssi, dist)
        return jsonify({"status": "success", "message": "Heatmap point saved"})
    else:
        samples = db.get_heatmap_samples()
        return jsonify(samples)

@app.route("/api/heatmap/idw", methods=["POST"])
def get_idw_grid():
    data = request.json or {}
    samples = data.get("samples", [])
    if not samples:
        db_samples = db.get_heatmap_samples()
        samples = [{"x": s["pos_x"], "y": s["pos_y"], "rssi": s["rssi"]} for s in db_samples]

    grid = idw_engine.interpolate_grid(samples, grid_width=40, grid_height=24, bounds=(800, 480))
    return jsonify({"grid": grid, "width": 40, "height": 24})

@app.route("/api/multi-ap/simulate", methods=["POST"])
def simulate_multi_ap():
    data = request.json or {}
    aps = data.get("access_points", [
        {"id": "AP1", "name": "AP 1 (Main Hall)", "x": 180, "y": 140},
        {"id": "AP2", "name": "AP 2 (Lab Wing)", "x": 620, "y": 140},
        {"id": "AP3", "name": "AP 3 (Library)", "x": 400, "y": 380}
    ])
    client_pos = data.get("client_position", {"x": 420, "y": 240})
    result = multi_ap_sim.simulate_environment(aps, client_pos)
    return jsonify(result)

@app.route("/api/export/csv", methods=["GET"])
def export_csv():
    csv_content = db.export_csv_string()
    return Response(
        csv_content,
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=wifi_telemetry_report.csv"}
    )

@app.route("/api/report/html", methods=["GET"])
def generate_html_report():
    summary = db.get_analytics_summary()
    recent = db.get_recent_telemetry(limit=20)

    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Academic Wi-Fi Performance Audit Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background: #fff; color: #111; }}
        h1 {{ border-bottom: 2px solid #2563eb; padding-bottom: 8px; color: #1e3a8a; }}
        .meta-box {{ background: #f1f5f9; border-left: 4px solid #2563eb; padding: 12px 18px; margin-bottom: 24px; }}
        .grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }}
        .card {{ background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; text-align: center; }}
        .card-val {{ font-size: 1.8rem; font-weight: bold; color: #2563eb; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 0.9rem; }}
        th, td {{ border: 1px solid #cbd5e1; padding: 10px; text-align: left; }}
        th {{ background: #f1f5f9; }}
    </style>
</head>
<body>
    <h1>Wi-Fi Signal Strength & Network Performance Audit Report</h1>
    <div class="meta-box">
        <strong>Course:</strong> Computer Networks B.Tech Project<br>
        <strong>Student Team:</strong> Anuprakash Dubey (23BDS0162), C. Koushik Kumar (24BCE2320), A. Roohan Prakaash (23BCE0209)<br>
        <strong>Generated At:</strong> Live Session
    </div>

    <h2>Executive Summary Metrics</h2>
    <div class="grid">
        <div class="card"><div class="card-val">{summary['total_samples']}</div><div>Total Telemetry Samples</div></div>
        <div class="card"><div class="card-val">{summary['avg_rssi']} dBm</div><div>Average RSSI</div></div>
        <div class="card"><div class="card-val">{summary['stability_percentage']}%</div><div>Network Stability Score</div></div>
        <div class="card"><div class="card-val">{summary['weak_signal_count']}</div><div>Weak Signal Anomalies</div></div>
    </div>

    <h2>Recent Telemetry Log Excerpt</h2>
    <table>
        <thead>
            <tr><th>ID</th><th>Timestamp</th><th>SSID</th><th>Raw RSSI</th><th>Kalman RSSI</th><th>Est Distance</th><th>Rating</th></tr>
        </thead>
        <tbody>
            {"".join(f"<tr><td>{r['id']}</td><td>{r['timestamp']}</td><td>{r['ssid']}</td><td>{r['raw_rssi']} dBm</td><td>{r['kalman_rssi']} dBm</td><td>{r['estimated_distance']} m</td><td>{r['rating']}</td></tr>" for r in recent)}
        </tbody>
    </table>

    <script>window.print();</script>
</body>
</html>"""
    return Response(html, mimetype="text/html")

@app.route("/api/settings", methods=["GET", "POST"])
def handle_settings():
    if request.method == "POST":
        data = request.json or {}
        if "alert_threshold" in data:
            config_state["alert_threshold"] = float(data["alert_threshold"])
        if "path_loss_exponent" in data:
            config_state["path_loss_exponent"] = float(data["path_loss_exponent"])
        if "channel_bandwidth_mhz" in data:
            config_state["channel_bandwidth_mhz"] = float(data["channel_bandwidth_mhz"])
        return jsonify({"status": "success", "config": config_state})
    return jsonify(config_state)

if __name__ == "__main__":
    print("=" * 70)
    print("  Wi-Fi Signal Strength Monitoring System — B.Tech CN Project Server  ")
    print("  Advanced Academic Edition Running on: http://127.0.0.1:5000")
    print("=" * 70)
    app.run(host="0.0.0.0", port=5000, debug=False)
