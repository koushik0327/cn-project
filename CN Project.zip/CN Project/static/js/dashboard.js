/**
 * Wi-Fi Signal Strength Monitoring System - Dashboard Frontend Logic (Advanced Academic Edition)
 * Pure Native HTML5 Canvas 2D Real-Time Line & Bar Charting (100% Offline, Zero External CDN Dependencies).
 */

// Global State
let chartDataStream = { labels: [], raw: [], kalman: [] };
let pingDataStream = { min: 0, avg: 0, jitter: 0, max: 0 };
let heatmapPoints = [];
let audioCtx = null;
let lastAlertTime = 0;
let currentScanMode = "hardware";
const MAX_CHART_POINTS = 30;

// Multi-AP Roaming State
let multiAps = [
  { id: "AP1", name: "AP 1 (Main Hall)", x: 180, y: 140 },
  { id: "AP2", name: "AP 2 (Lab Wing)", x: 620, y: 140 },
  { id: "AP3", name: "AP 3 (Library)", x: 400, y: 340 }
];
let clientPos = { x: 400, y: 220 };

// Helpers for Safe Exception-Free Property Access
function safeNum(val, def = 0) {
  const n = parseFloat(val);
  return isNaN(n) ? def : n;
}

function safeStr(val, def = "--") {
  if (val === null || val === undefined || val === "") return def;
  return String(val);
}

// Initialize Dashboard
document.addEventListener("DOMContentLoaded", () => {
  initHeatmapCanvas();
  initMultiApCanvas();
  fetchInitialAnalytics();
  startTelemetryLoop();
  loadHistoryLogs();

  // Initial Canvas Render
  renderRssiCanvasChart();
  renderPingCanvasChart();

  window.addEventListener("resize", () => {
    renderRssiCanvasChart();
    renderPingCanvasChart();
  });
});

// Tab Navigation
function switchTab(tabId, btnElement) {
  document.querySelectorAll(".tab-content").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".nav-tab-btn").forEach(el => el.classList.remove("active"));
  
  document.getElementById(tabId).classList.add("active");
  btnElement.classList.add("active");

  if (tabId === "heatmapTab") {
    renderIdwHeatmap();
  } else if (tabId === "multiApTab") {
    renderMultiApCanvas();
  } else if (tabId === "logsTab") {
    loadHistoryLogs();
  }
}

// Continuous Telemetry Polling Loop
function startTelemetryLoop() {
  setInterval(async () => {
    try {
      const res = await fetch("/api/telemetry");
      if (!res.ok) return;
      const data = await res.json();

      try { updateMetrics(data); } catch(e) { console.error("updateMetrics error:", e); }
      try { updateChartData(data); } catch(e) { console.error("updateChartData error:", e); }
      try { checkAlerts(data); } catch(e) { console.error("checkAlerts error:", e); }
    } catch (err) {
      console.warn("Telemetry poll error:", err);
    }
  }, 1000);
}

// Mode Toggle Function
async function toggleScanMode() {
  currentScanMode = currentScanMode === "hardware" ? "simulated" : "hardware";
  try {
    const res = await fetch("/api/mode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: currentScanMode })
    });
    if (res.ok) {
      const data = await res.json();
    }
  } catch (e) {}
}

// Update Metric Cards & Link Info
function updateMetrics(data) {
  if (!data) return;

  const isConnected = data.is_connected !== false;

  // 1. Basic Link & Hardware Parameters (Updated FIRST)
  try {
    const ssidEl = document.getElementById("infoSsid");
    if (ssidEl) ssidEl.innerText = safeStr(data.ssid, "Wi-Fi Disconnected");

    const bssidEl = document.getElementById("infoBssid");
    if (bssidEl) bssidEl.innerText = safeStr(data.bssid, "00:00:00:00:00:00");

    const chanEl = document.getElementById("infoChannel");
    if (chanEl) chanEl.innerText = data.channel ? `${data.channel} (${safeStr(data.frequency, "2.4 GHz")})` : "N/A";

    const radioEl = document.getElementById("infoRadio");
    if (radioEl) radioEl.innerText = safeStr(data.radio_type, "802.11n");

    const speedEl = document.getElementById("infoSpeed");
    if (speedEl) {
      const tx = safeStr(data.tx_rate, "0");
      const rx = safeStr(data.rx_rate, "0");
      const txStr = tx.includes("Mbps") ? tx : `${tx} Mbps`;
      const rxStr = rx.includes("Mbps") ? rx : `${rx} Mbps`;
      speedEl.innerText = `${txStr} / ${rxStr}`;
    }

    const noiseEl = document.getElementById("infoNoise");
    if (noiseEl) noiseEl.innerText = `${safeNum(data.noise_floor, -95)} dBm`;
  } catch (e) {
    console.error("Link params error:", e);
  }

  // 2. Main Top Cards (RSSI, Distance, Capacity)
  try {
    if (!isConnected) {
      document.getElementById("metricRssi").innerText = "-100.0";
      document.getElementById("metricRawRssi").innerText = "-100.0";
      document.getElementById("metricSignalPct").innerText = "0%";
      document.getElementById("metricDistance").innerText = "N/A";
      document.getElementById("metricShannon").innerText = "0.0";
      
      const ratingEl = document.getElementById("metricRating");
      if (ratingEl) {
        ratingEl.innerText = "Disconnected";
        ratingEl.style.color = "#6b7280";
      }
      document.getElementById("metricRecommendation").innerText = "Wi-Fi Interface is Disconnected or Turned OFF";

      const modeBadge = document.getElementById("scanModeBadge");
      if (modeBadge) {
        modeBadge.innerText = "Wi-Fi Disconnected ❌ (Click to Toggle Demo)";
        modeBadge.style.background = "rgba(239, 68, 68, 0.2)";
        modeBadge.style.color = "#f87171";
        modeBadge.style.borderColor = "rgba(239, 68, 68, 0.4)";
      }
    } else {
      document.getElementById("metricRssi").innerText = safeNum(data.kalman_rssi, -60).toFixed(1);
      document.getElementById("metricRawRssi").innerText = safeNum(data.raw_rssi, -60).toFixed(1);
      document.getElementById("metricSignalPct").innerText = `${safeNum(data.signal_percent, 50)}%`;
      document.getElementById("metricDistance").innerText = safeNum(data.estimated_distance, 1.0).toFixed(2);
      
      if (data.shannon_capacity_mbps !== undefined) {
        document.getElementById("metricShannon").innerText = safeNum(data.shannon_capacity_mbps, 0).toFixed(1);
      }

      const ratingEl = document.getElementById("metricRating");
      if (ratingEl) {
        ratingEl.innerText = safeStr(data.rating, "Good");
        ratingEl.style.color = safeStr(data.rating_color, "#06b6d4");
      }
      document.getElementById("metricRecommendation").innerText = safeStr(data.recommendation, "Stable Connection");

      const modeBadge = document.getElementById("scanModeBadge");
      if (modeBadge) {
        if (data.is_simulated) {
          modeBadge.innerText = "Demo Simulator 🔄";
          modeBadge.style.background = "rgba(245, 158, 11, 0.15)";
          modeBadge.style.color = "#fbbf24";
          modeBadge.style.borderColor = "rgba(245, 158, 11, 0.3)";
        } else {
          modeBadge.innerText = "Hardware Live 🔄";
          modeBadge.style.background = "rgba(139, 92, 246, 0.15)";
          modeBadge.style.color = "#c084fc";
          modeBadge.style.borderColor = "rgba(139, 92, 246, 0.3)";
        }
      }
    }
  } catch (e) {
    console.error("Main metrics error:", e);
  }

  // 3. Signal Trend & TTD
  try {
    if (data.trend) {
      const slopeVal = safeNum(data.trend.slope_dbm_per_sec, 0);
      const slopeEl = document.getElementById("metricTrendSlope");
      if (slopeEl) slopeEl.innerText = (slopeVal > 0 ? "+" : "") + slopeVal.toFixed(2);
      
      const labelEl = document.getElementById("metricTrendLabel");
      if (labelEl) {
        const trendText = safeStr(data.trend.trend, "STABLE");
        labelEl.innerText = trendText;
        labelEl.style.color = trendText === "DEGRADATING" ? "#ef4444" : (trendText === "IMPROVING" ? "#10b981" : "#60a5fa");
      }

      const ttdEl = document.getElementById("metricTtd");
      if (ttdEl) {
        ttdEl.innerText = data.trend.ttd_seconds ? `TTD: ${safeNum(data.trend.ttd_seconds).toFixed(1)}s` : (isConnected ? "TTD: Safe" : "TTD: Disconnected");
      }
    }
  } catch (e) {
    console.error("Trend metrics error:", e);
  }

  // 4. Z-Score Anomaly Engine
  try {
    if (data.anomaly) {
      const zVal = safeNum(data.anomaly.z_score, 0);
      const zEl = document.getElementById("metricZScore");
      if (zEl) zEl.innerText = zVal.toFixed(2);

      const zBadge = document.getElementById("metricAnomalySeverity");
      if (zBadge) {
        const sev = safeStr(data.anomaly.severity, "NORMAL");
        zBadge.innerText = sev;
        if (data.anomaly.is_anomaly || !isConnected) {
          zBadge.style.background = "rgba(239, 68, 68, 0.2)";
          zBadge.style.color = "#f87171";
        } else {
          zBadge.style.background = "rgba(16, 185, 129, 0.15)";
          zBadge.style.color = "#34d399";
        }
      }
    }
  } catch (e) {
    console.error("Z score error:", e);
  }
}

// Push Data & Render Native HTML5 Canvas Line Chart
function updateChartData(data) {
  const timeStr = new Date().toLocaleTimeString().split(" ")[0];
  const rawVal = (data.is_connected !== false) ? safeNum(data.raw_rssi, -60) : -100.0;
  const kalmanVal = (data.is_connected !== false) ? safeNum(data.kalman_rssi, -60) : -100.0;

  chartDataStream.labels.push(timeStr);
  chartDataStream.raw.push(rawVal);
  chartDataStream.kalman.push(kalmanVal);

  if (chartDataStream.labels.length > MAX_CHART_POINTS) {
    chartDataStream.labels.shift();
    chartDataStream.raw.shift();
    chartDataStream.kalman.shift();
  }

  renderRssiCanvasChart();
}

// --------------------------------------------------------------------------
// PURE NATIVE 2D CANVAS LINE CHART RENDERER (Zero External CDN Dependencies)
// --------------------------------------------------------------------------
function renderRssiCanvasChart() {
  const canvas = document.getElementById("rssiChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  
  const rect = canvas.parentElement.getBoundingClientRect();
  const w = rect.width > 50 ? rect.width : 700;
  const h = rect.height > 50 ? rect.height : 320;
  
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }

  const paddingLeft = 50;
  const paddingBottom = 30;
  const paddingTop = 20;
  const paddingRight = 20;

  const graphW = w - paddingLeft - paddingRight;
  const graphH = h - paddingTop - paddingBottom;

  ctx.clearRect(0, 0, w, h);

  const minY = -105;
  const maxY = -25;

  function valToY(val) {
    const clamped = Math.max(minY, Math.min(maxY, val));
    const pct = (clamped - minY) / (maxY - minY);
    return h - paddingBottom - (pct * graphH);
  }

  // Draw Grid Lines & Y Labels
  ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
  ctx.lineWidth = 1;
  ctx.fillStyle = "#9ca3af";
  ctx.font = "11px 'JetBrains Mono', monospace";
  ctx.textAlign = "right";

  const yTicks = [-25, -40, -55, -70, -85, -100];
  yTicks.forEach(yVal => {
    const yPos = valToY(yVal);
    ctx.beginPath();
    ctx.moveTo(paddingLeft, yPos);
    ctx.lineTo(w - paddingRight, yPos);
    ctx.stroke();
    ctx.fillText(`${yVal}`, paddingLeft - 8, yPos + 4);
  });

  const numPoints = chartDataStream.raw.length;
  if (numPoints === 0) return;

  const stepX = graphW / Math.max(1, MAX_CHART_POINTS - 1);

  // Draw X Time Labels
  ctx.textAlign = "center";
  chartDataStream.labels.forEach((label, i) => {
    if (i % 5 === 0 || i === numPoints - 1) {
      const xPos = paddingLeft + (i * stepX);
      ctx.fillText(label, xPos, h - 8);
    }
  });

  // 1. Draw Raw RSSI Stream (Blue Line & Glow Fill)
  ctx.beginPath();
  chartDataStream.raw.forEach((val, i) => {
    const x = paddingLeft + (i * stepX);
    const y = valToY(val);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });

  const lastIdx = numPoints - 1;
  ctx.lineTo(paddingLeft + (lastIdx * stepX), h - paddingBottom);
  ctx.lineTo(paddingLeft, h - paddingBottom);
  ctx.closePath();

  const grad = ctx.createLinearGradient(0, paddingTop, 0, h - paddingBottom);
  grad.addColorStop(0, "rgba(59, 130, 246, 0.3)");
  grad.addColorStop(1, "rgba(59, 130, 246, 0.0)");
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.beginPath();
  chartDataStream.raw.forEach((val, i) => {
    const x = paddingLeft + (i * stepX);
    const y = valToY(val);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = "#3b82f6";
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // 2. Draw Kalman Filtered Line (Emerald Green Line)
  ctx.beginPath();
  chartDataStream.kalman.forEach((val, i) => {
    const x = paddingLeft + (i * stepX);
    const y = valToY(val);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = "#10b981";
  ctx.lineWidth = 3.5;
  ctx.stroke();

  // Draw active point dot
  const lastKalman = chartDataStream.kalman[lastIdx];
  const lastX = paddingLeft + (lastIdx * stepX);
  const lastY = valToY(lastKalman);

  ctx.fillStyle = "#10b981";
  ctx.beginPath();
  ctx.arc(lastX, lastY, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.stroke();
}

// --------------------------------------------------------------------------
// PURE NATIVE 2D CANVAS BAR CHART RENDERER FOR DIAGNOSTICS
// --------------------------------------------------------------------------
function renderPingCanvasChart() {
  const canvas = document.getElementById("pingChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  const rect = canvas.parentElement.getBoundingClientRect();
  const w = rect.width > 50 ? rect.width : 500;
  const h = rect.height > 50 ? rect.height : 200;

  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }

  const paddingLeft = 40;
  const paddingBottom = 25;
  const paddingTop = 15;
  const paddingRight = 15;

  ctx.clearRect(0, 0, w, h);

  const labels = ["Min RTT", "Avg RTT", "Jitter", "Max RTT"];
  const values = [pingDataStream.min, pingDataStream.avg, pingDataStream.jitter, pingDataStream.max];
  const maxVal = Math.max(10, Math.max(...values) * 1.2);

  const barWidth = 45;
  const graphW = w - paddingLeft - paddingRight;
  const stepX = graphW / labels.length;

  ctx.strokeStyle = "rgba(255, 255, 255, 0.06)";
  ctx.lineWidth = 1;
  ctx.fillStyle = "#9ca3af";
  ctx.font = "11px 'JetBrains Mono', monospace";
  ctx.textAlign = "center";

  labels.forEach((label, i) => {
    const val = values[i];
    const barH = (val / maxVal) * (h - paddingTop - paddingBottom);
    const x = paddingLeft + (i * stepX) + (stepX / 2) - (barWidth / 2);
    const y = h - paddingBottom - barH;

    // Bar
    ctx.fillStyle = "rgba(6, 182, 212, 0.4)";
    ctx.fillRect(x, y, barWidth, barH);
    ctx.strokeStyle = "#06b6d4";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x, y, barWidth, barH);

    // Value Text
    ctx.fillStyle = "#f9fafb";
    ctx.fillText(`${val.toFixed(1)} ms`, x + (barWidth / 2), y - 5);

    // Label Text
    ctx.fillStyle = "#9ca3af";
    ctx.fillText(label, x + (barWidth / 2), h - 8);
  });
}

// Initial Analytics
async function fetchInitialAnalytics() {
  try {
    const res = await fetch("/api/analytics");
    if (!res.ok) return;
    const data = await res.json();
  } catch (e) {}
}

// Audio Synth & Visual Alert Engine
function checkAlerts(data) {
  if (data.is_critical && data.is_connected !== false) {
    const banner = document.getElementById("alertBanner");
    if (banner) {
      document.getElementById("alertBannerTitle").innerText = `CRITICAL SIGNAL EVENT (${data.kalman_rssi} dBm)`;
      document.getElementById("alertBannerText").innerText = `Signal level is below threshold or Z-Score anomaly detected! Distance: ~${data.estimated_distance}m to AP. High dropout risk.`;
      banner.classList.add("show");
    }

    const now = Date.now();
    if (now - lastAlertTime > 5000) {
      playAlertBeep();
      lastAlertTime = now;
    }
  } else if (data.is_connected === false) {
    const banner = document.getElementById("alertBanner");
    if (banner) {
      document.getElementById("alertBannerTitle").innerText = `WI-FI INTERFACE DISCONNECTED`;
      document.getElementById("alertBannerText").innerText = `Wi-Fi is turned OFF or disconnected. Turn on Wi-Fi or click 'Demo Simulator' in header to test telemetry features.`;
      banner.classList.add("show");
    }
  }
}

function dismissAlert() {
  const banner = document.getElementById("alertBanner");
  if (banner) banner.classList.remove("show");
}

function playAlertBeep() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.3);
    
    gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    
    osc.start();
    osc.stop(audioCtx.currentTime + 0.3);
  } catch (e) {}
}

/* ==========================================================================
   IDW SPATIAL HEATMAP CANVAS
   ========================================================================== */
function initHeatmapCanvas() {
  const canvas = document.getElementById("heatmapCanvas");
  if (!canvas) return;
  canvas.addEventListener("click", (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const currentRssi = parseFloat(document.getElementById("metricRssi").innerText) || -55;
    const currentDist = parseFloat(document.getElementById("metricDistance").innerText) || 2.5;
    const label = document.getElementById("heatmapLocationInput").value || `Point ${heatmapPoints.length + 1}`;

    heatmapPoints.push({ x, y, rssi: currentRssi, distance: currentDist, label });
    renderIdwHeatmap();

    fetch("/api/heatmap", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label, x, y, rssi: currentRssi, distance: currentDist })
    });
  });
}

function clearHeatmapCanvas() {
  heatmapPoints = [];
  renderIdwHeatmap();
}

function generateSimulatedGrid() {
  heatmapPoints = [
    { x: 150, y: 120, rssi: -38, distance: 0.8, label: "Access Point (Main Router)" },
    { x: 280, y: 150, rssi: -52, distance: 2.1, label: "Office Desk 1" },
    { x: 420, y: 220, rssi: -64, distance: 4.5, label: "Conference Room" },
    { x: 600, y: 350, rssi: -78, distance: 8.2, label: "Corridor Dead Zone" },
    { x: 720, y: 400, rssi: -86, distance: 12.0, label: "Outside Partition" }
  ];
  renderIdwHeatmap();
}

async function renderIdwHeatmap() {
  const canvas = document.getElementById("heatmapCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (heatmapPoints.length > 0) {
    try {
      const res = await fetch("/api/heatmap/idw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ samples: heatmapPoints })
      });
      
      if (res.ok) {
        const idwData = await res.json();
        const grid = idwData.grid;
        const cellW = canvas.width / idwData.width;
        const cellH = canvas.height / idwData.height;

        for (let j = 0; j < idwData.height; j++) {
          for (let i = 0; i < idwData.width; i++) {
            const rssi = grid[j][i];
            ctx.fillStyle = getRssiHeatColor(rssi, 0.45);
            ctx.fillRect(i * cellW, j * cellH, cellW + 0.5, cellH + 0.5);
          }
        }
      }
    } catch (e) {}
  }

  // Draw Grid Lines
  ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += 40) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
  }

  // Draw Point Markers & Labels
  heatmapPoints.forEach(pt => {
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#3b82f6";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = "#f9fafb";
    ctx.font = "11px Outfit";
    ctx.fillText(`${pt.label} (${pt.rssi} dBm)`, pt.x + 10, pt.y + 4);
  });
}

function getRssiHeatColor(rssi, alpha = 0.5) {
  if (rssi >= -55) return `rgba(16, 185, 129, ${alpha})`;
  if (rssi >= -68) return `rgba(59, 130, 246, ${alpha})`;
  if (rssi >= -78) return `rgba(245, 158, 11, ${alpha})`;
  return `rgba(239, 68, 68, ${alpha})`;
}

function recordHeatmapPointFromForm() {
  const label = document.getElementById("heatmapLocationInput").value || "Sampled Room";
  const rssi = parseFloat(document.getElementById("heatmapRssiInput").value) || -60;
  
  const x = Math.floor(Math.random() * 600) + 100;
  const y = Math.floor(Math.random() * 300) + 80;

  heatmapPoints.push({ x, y, rssi, distance: 3.0, label });
  renderIdwHeatmap();
}

/* ==========================================================================
   MULTI-AP ROAMING SIMULATOR CANVAS
   ========================================================================== */
function initMultiApCanvas() {
  const wrapper = document.getElementById("multiApCanvasWrapper");
  if (!wrapper) return;
  
  wrapper.addEventListener("click", (e) => {
    const rect = wrapper.getBoundingClientRect();
    clientPos.x = e.clientX - rect.left;
    clientPos.y = e.clientY - rect.top;
    simulateMultiApHandover();
  });
}

async function simulateMultiApHandover() {
  try {
    const res = await fetch("/api/multi-ap/simulate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ access_points: multiAps, client_position: clientPos })
    });
    
    if (!res.ok) return;
    const data = await res.json();

    document.getElementById("multiApActive").innerText = data.connected_ap || "None";
    document.getElementById("multiApRssi").innerText = `${data.best_rssi} dBm`;
    document.getElementById("multiApCombined").innerText = `${data.combined_rssi} dBm`;
    document.getElementById("multiApRecommendation").innerText = data.optimization_recommendation.suggestion;

    renderMultiApCanvas(data);
  } catch (e) {}
}

function renderMultiApCanvas(simResult = null) {
  const canvas = document.getElementById("multiApCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += 40) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
  }

  multiAps.forEach(ap => {
    const isConnected = simResult && simResult.connected_ap === ap.id;

    ctx.beginPath();
    ctx.arc(ap.x, ap.y, 160, 0, Math.PI * 2);
    ctx.fillStyle = isConnected ? "rgba(16, 185, 129, 0.08)" : "rgba(59, 130, 246, 0.05)";
    ctx.fill();
    ctx.strokeStyle = isConnected ? "rgba(16, 185, 129, 0.4)" : "rgba(59, 130, 246, 0.2)";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = isConnected ? "#10b981" : "#3b82f6";
    ctx.beginPath(); ctx.arc(ap.x, ap.y, 12, 0, Math.PI * 2); ctx.fill();
    
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 12px Outfit";
    ctx.fillText("📡 " + ap.name, ap.x - 40, ap.y - 18);
  });

  ctx.fillStyle = "#f59e0b";
  ctx.beginPath();
  ctx.arc(clientPos.x, clientPos.y, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = "#fbbf24";
  ctx.font = "bold 12px Outfit";
  ctx.fillText("💻 Client Device", clientPos.x + 14, clientPos.y + 4);

  if (simResult && simResult.connected_ap) {
    const activeAp = multiAps.find(a => a.id === simResult.connected_ap);
    if (activeAp) {
      ctx.beginPath();
      ctx.moveTo(clientPos.x, clientPos.y);
      ctx.lineTo(activeAp.x, activeAp.y);
      ctx.strokeStyle = "#10b981";
      ctx.setLineDash([6, 6]);
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }
}

/* ==========================================================================
   NETWORK PING DIAGNOSTICS & MULTI-TARGET MATRIX
   ========================================================================== */
async function runPingAudit() {
  const host = document.getElementById("diagHostInput").value || "8.8.8.8";
  const count = parseInt(document.getElementById("diagCountInput").value) || 4;

  try {
    const res = await fetch("/api/diagnostics/ping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: host, count })
    });
    
    if (!res.ok) return;
    const data = await res.json();

    document.getElementById("diagAvgLatency").innerText = data.avg_latency_ms.toFixed(1);
    document.getElementById("diagJitter").innerText = data.jitter_ms.toFixed(1);
    
    const lossEl = document.getElementById("diagPacketLoss");
    lossEl.innerText = data.packet_loss_pct.toFixed(1);
    lossEl.style.color = data.packet_loss_pct > 0 ? "#ef4444" : "#10b981";

    pingDataStream.min = data.min_latency_ms;
    pingDataStream.avg = data.avg_latency_ms;
    pingDataStream.jitter = data.jitter_ms;
    pingDataStream.max = data.max_latency_ms;

    renderPingCanvasChart();
  } catch (err) {}
}

async function runMultiTargetMatrix() {
  const tbody = document.getElementById("multiPingTableBody");
  tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 16px;">Running parallel multi-host diagnostic matrix...</td></tr>`;

  try {
    const res = await fetch("/api/diagnostics/multi-ping");
    if (!res.ok) return;
    const results = await res.json();

    tbody.innerHTML = "";
    results.forEach(row => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${row.host}</strong></td>
        <td>${row.avg_latency_ms} ms</td>
        <td>${row.packet_loss_pct}%</td>
        <td><span class="status-badge" style="background: rgba(16,185,129,0.15); color: #34d399;">${row.status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) {}
}

/* ==========================================================================
   TELEMETRY AUDIT LOG TABLE
   ========================================================================== */
async function loadHistoryLogs() {
  try {
    const res = await fetch("/api/history?limit=30");
    if (!res.ok) return;
    const logs = await res.json();

    const tbody = document.getElementById("telemetryTableBody");
    tbody.innerHTML = "";

    if (logs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 20px;">No telemetry records logged yet.</td></tr>`;
      return;
    }

    logs.forEach(row => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${row.id}</td>
        <td>${row.timestamp.split(" ")[1] || row.timestamp}</td>
        <td>${row.ssid}</td>
        <td style="font-family: 'JetBrains Mono';">${row.raw_rssi} dBm</td>
        <td style="font-family: 'JetBrains Mono'; font-weight: 600;">${row.kalman_rssi} dBm</td>
        <td>${row.estimated_distance} m</td>
        <td><span class="status-badge" style="background: rgba(59, 130, 246, 0.15); color: #60a5fa;">${row.rating}</span></td>
        <td>Ch ${row.channel}</td>
        <td>${row.is_critical ? '<span style="color: #ef4444; font-weight: bold;">CRITICAL</span>' : '<span style="color: #10b981;">NORMAL</span>'}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) {}
}

/* ==========================================================================
   SETTINGS FORM
   ========================================================================== */
async function saveSettings(e) {
  e.preventDefault();
  const threshold = parseFloat(document.getElementById("configThreshold").value);
  const pathLoss = parseFloat(document.getElementById("configPathLoss").value);
  const bw = parseFloat(document.getElementById("configBandwidth").value) || 20;

  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ alert_threshold: threshold, path_loss_exponent: pathLoss, channel_bandwidth_mhz: bw })
    });
    
    if (res.ok) {
      document.getElementById("metricPathExp").innerText = pathLoss;
      alert("Advanced settings saved successfully!");
    }
  } catch (err) {
    alert("Error saving settings.");
  }
}
