@echo off
title Wi-Fi Signal Strength Monitoring System - Server
echo ======================================================================
echo   Wi-Fi Signal Strength Monitoring System — B.Tech CN Project
echo   Student Team: Anuprakash Dubey, C. Koushik Kumar, A. Roohan Prakaash
echo ======================================================================
echo.
echo Opening Web Dashboard in Browser...
start http://127.0.0.1:5000
echo.
echo Starting Server...
python app.py
pause
