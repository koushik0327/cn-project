"""
Network Diagnostics Engine
Performs single and multi-target latency ping tests, jitter calculation,
and packet loss evaluation for network health auditing.
"""

import os
import platform
import subprocess
import re
import statistics
import concurrent.futures

class NetworkDiagnostics:
    def __init__(self):
        self.os_type = platform.system().lower()

    def run_ping_test(self, host="8.8.8.8", count=4) -> dict:
        """
        Pings a single target host and parses average latency (ms), jitter (ms), and packet loss (%).
        """
        try:
            if "windows" in self.os_type:
                cmd = ["ping", "-n", str(count), "-w", "1000", host]
            else:
                cmd = ["ping", "-c", str(count), "-W", "1", host]

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                creationflags=0x08000000 if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            stdout, stderr = process.communicate(timeout=6)

            rtts = []
            packet_loss = 0.0

            if "windows" in self.os_type:
                time_matches = re.findall(r"time[=<](\d+)ms", stdout, re.IGNORECASE)
                for t in time_matches:
                    rtts.append(float(t))
                
                loss_match = re.search(r"\((\d+)%\s*loss\)", stdout, re.IGNORECASE)
                if loss_match:
                    packet_loss = float(loss_match.group(1))
            else:
                time_matches = re.findall(r"time=([\d.]+)\s*ms", stdout, re.IGNORECASE)
                for t in time_matches:
                    rtts.append(float(t))
                
                loss_match = re.search(r"([\d.]+)%\s*packet loss", stdout, re.IGNORECASE)
                if loss_match:
                    packet_loss = float(loss_match.group(1))

            if not rtts:
                return {
                    "host": host,
                    "status": "Failed / Unreachable",
                    "avg_latency_ms": 0.0,
                    "min_latency_ms": 0.0,
                    "max_latency_ms": 0.0,
                    "jitter_ms": 0.0,
                    "packet_loss_pct": 100.0,
                    "samples_received": 0,
                    "samples_sent": count
                }

            avg_rtt = round(sum(rtts) / len(rtts), 2)
            min_rtt = round(min(rtts), 2)
            max_rtt = round(max(rtts), 2)
            jitter = round(statistics.stdev(rtts), 2) if len(rtts) > 1 else 0.0
            status = "Optimal" if avg_rtt < 50 and packet_loss == 0 else ("Moderate" if avg_rtt < 120 else "High Latency")

            return {
                "host": host,
                "status": status,
                "avg_latency_ms": avg_rtt,
                "min_latency_ms": min_rtt,
                "max_latency_ms": max_rtt,
                "jitter_ms": jitter,
                "packet_loss_pct": packet_loss,
                "samples_received": len(rtts),
                "samples_sent": count
            }
        except Exception as e:
            return {
                "host": host,
                "status": f"Error: {str(e)}",
                "avg_latency_ms": 0.0,
                "min_latency_ms": 0.0,
                "max_latency_ms": 0.0,
                "jitter_ms": 0.0,
                "packet_loss_pct": 100.0,
                "samples_received": 0,
                "samples_sent": count
            }

    def run_multi_ping_matrix(self, hosts=None, count=3) -> list:
        """
        Executes concurrent ping diagnostics across multiple target hosts
        (e.g., Gateway, Google DNS, Cloudflare, OpenDNS).
        """
        if hosts is None:
            hosts = ["8.8.8.8", "1.1.1.1", "208.67.222.222"]

        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(hosts)) as executor:
            future_to_host = {executor.submit(self.run_ping_test, host, count): host for host in hosts}
            for future in concurrent.futures.as_completed(future_to_host):
                try:
                    res = future.result()
                    results.append(res)
                except Exception:
                    host = future_to_host[future]
                    results.append({"host": host, "status": "Failed", "avg_latency_ms": 0.0, "jitter_ms": 0.0, "packet_loss_pct": 100.0})
        return results
