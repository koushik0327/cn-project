#!/bin/bash
echo "======================================================================"
echo "  Wi-Fi Signal Strength Monitoring System — B.Tech CN Project"
echo "  Student Team: Anuprakash Dubey, C. Koushik Kumar, A. Roohan Prakaash"
echo "======================================================================"
echo ""
echo "Installing requirements..."
pip3 install -r requirements.txt
echo ""
echo "Starting Web Dashboard Server on http://127.0.0.1:5000..."
python3 app.py
