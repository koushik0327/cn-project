"""
Database Persistence & Analytics Module
Uses SQLite3 for storing timestamped RSSI logs, alert triggers,
spatial heatmap points, and diagnostic audit logs.
"""

import sqlite3
import csv
import io
import datetime
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wifi_monitor.db")

class DatabaseManager:
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Telemetry Log Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS telemetry_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    ssid TEXT,
                    bssid TEXT,
                    raw_rssi REAL,
                    kalman_rssi REAL,
                    sma_rssi REAL,
                    estimated_distance REAL,
                    rating TEXT,
                    channel INTEGER,
                    is_critical INTEGER,
                    is_simulated INTEGER
                )
            """)

            # Alert Event Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS alert_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    event_type TEXT,
                    rssi REAL,
                    message TEXT,
                    status TEXT
                )
            """)

            # Spatial Heatmap Point Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS heatmap_samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    location_label TEXT,
                    pos_x REAL,
                    pos_y REAL,
                    rssi REAL,
                    estimated_distance REAL
                )
            """)

            # Diagnostic Ping Audit Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS diagnostic_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    target_host TEXT,
                    avg_latency_ms REAL,
                    jitter_ms REAL,
                    packet_loss_pct REAL,
                    status TEXT
                )
            """)
            conn.commit()

    def log_telemetry(self, data: dict):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO telemetry_logs (
                    ssid, bssid, raw_rssi, kalman_rssi, sma_rssi,
                    estimated_distance, rating, channel, is_critical, is_simulated
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data.get("ssid"),
                data.get("bssid"),
                data.get("raw_rssi"),
                data.get("kalman_rssi"),
                data.get("sma_rssi"),
                data.get("estimated_distance"),
                data.get("rating"),
                data.get("channel"),
                1 if data.get("is_critical") else 0,
                1 if data.get("is_simulated") else 0
            ))
            conn.commit()

    def log_alert(self, event_type: str, rssi: float, message: str, status="TRIGGERED"):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO alert_logs (event_type, rssi, message, status)
                VALUES (?, ?, ?, ?)
            """, (event_type, rssi, message, status))
            conn.commit()

    def log_diagnostic(self, target: str, latency: float, jitter: float, loss: float, status: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO diagnostic_logs (target_host, avg_latency_ms, jitter_ms, packet_loss_pct, status)
                VALUES (?, ?, ?, ?, ?)
            """, (target, latency, jitter, loss, status))
            conn.commit()

    def save_heatmap_sample(self, label: str, x: float, y: float, rssi: float, distance: float):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO heatmap_samples (location_label, pos_x, pos_y, rssi, estimated_distance)
                VALUES (?, ?, ?, ?, ?)
            """, (label, x, y, rssi, distance))
            conn.commit()

    def get_recent_telemetry(self, limit=60):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM telemetry_logs ORDER BY id DESC LIMIT ?
            """, (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in reversed(rows)]

    def get_all_alerts(self, limit=30):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM alert_logs ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_heatmap_samples(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM heatmap_samples ORDER BY id ASC")
            return [dict(row) for row in cursor.fetchall()]

    def get_analytics_summary(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) as total_samples, AVG(raw_rssi) as avg_rssi, MIN(raw_rssi) as min_rssi, MAX(raw_rssi) as max_rssi, AVG(estimated_distance) as avg_dist FROM telemetry_logs")
            row = cursor.fetchone()
            
            cursor.execute("SELECT COUNT(*) as critical_count FROM telemetry_logs WHERE is_critical = 1")
            crit_row = cursor.fetchone()

            total = row["total_samples"] or 0
            avg_rssi = round(row["avg_rssi"], 2) if row["avg_rssi"] else 0.0
            min_rssi = round(row["min_rssi"], 2) if row["min_rssi"] else 0.0
            max_rssi = round(row["max_rssi"], 2) if row["max_rssi"] else 0.0
            avg_dist = round(row["avg_dist"], 2) if row["avg_dist"] else 0.0
            critical_count = crit_row["critical_count"] or 0

            # Calculate network stability percentage
            stability_pct = 100.0 if total == 0 else round(((total - critical_count) / total) * 100.0, 1)

            return {
                "total_samples": total,
                "avg_rssi": avg_rssi,
                "min_rssi": min_rssi,
                "max_rssi": max_rssi,
                "avg_distance": avg_dist,
                "weak_signal_count": critical_count,
                "stability_percentage": stability_pct
            }

    def export_csv_string(self) -> str:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, timestamp, ssid, bssid, raw_rssi, kalman_rssi, sma_rssi, estimated_distance, rating, channel, is_critical FROM telemetry_logs ORDER BY id DESC")
            rows = cursor.fetchall()
            
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(["ID", "Timestamp", "SSID", "BSSID", "Raw RSSI (dBm)", "Kalman RSSI (dBm)", "SMA RSSI (dBm)", "Est Distance (m)", "Quality Rating", "Channel", "Weak Signal Alert"])
            
            for r in rows:
                writer.writerow([
                    r["id"], r["timestamp"], r["ssid"], r["bssid"],
                    r["raw_rssi"], r["kalman_rssi"], r["sma_rssi"],
                    r["estimated_distance"], r["rating"], r["channel"],
                    "YES" if r["is_critical"] else "NO"
                ])
            return output.getvalue()
