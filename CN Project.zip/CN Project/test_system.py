"""
Automated System Verification Tests (Advanced Academic Edition)
Validates signal processing algorithms, Shannon Capacity calculations,
Z-Score anomaly detection, IDW spatial heatmap interpolation,
Multi-AP roaming handover simulation, database transactions, and REST APIs.
"""

import unittest
import os
import json

from signal_processor import (
    KalmanFilter, MovingAverageFilter, PathLossEstimator,
    SignalQualityEvaluator, ShannonCapacityCalculator,
    ZScoreAnomalyDetector, SignalTrendPredictor
)
from heatmap_engine import IDWInterpolationEngine, MultiAPRoamingSimulator
from scanner import WiFiScanner
from database import DatabaseManager
from diagnostics import NetworkDiagnostics
from app import app, db, config_state

class TestAdvancedWiFiMonitoringSystem(unittest.TestCase):

    def test_01_kalman_filter(self):
        kf = KalmanFilter(initial_value=-60.0)
        smoothed = kf.update(-75.0)
        self.assertIsInstance(smoothed, float)
        self.assertGreater(smoothed, -75.0)

    def test_02_shannon_capacity_theorem(self):
        # C = B * log2(1 + SNR)
        # At -50 dBm RSSI and -95 dBm Noise Floor (SNR = 45 dB)
        cap = ShannonCapacityCalculator.calculate_capacity(-50.0, -95.0, 20.0)
        self.assertGreater(cap, 100.0)  # Should yield > 100 Mbps theoretical capacity

    def test_03_z_score_anomaly_detector(self):
        detector = ZScoreAnomalyDetector(window_size=10, threshold_z=2.5)
        # Feed normal steady stream
        for r in [-55.0, -56.0, -55.5, -54.8, -55.2]:
            res = detector.update(r)
            self.assertFalse(res["is_anomaly"])
        
        # Sudden deep drop anomaly
        drop_res = detector.update(-88.0)
        self.assertTrue(drop_res["is_anomaly"])
        self.assertIn("CRITICAL", drop_res["severity"])

    def test_04_signal_trend_predictor(self):
        predictor = SignalTrendPredictor(window_size=10)
        # Feed steady degradation stream
        for r in [-50, -54, -58, -62, -66, -70, -74]:
            res = predictor.update(r)
        
        self.assertEqual(res["trend"], "DEGRADATING")
        self.assertIsNotNone(res["ttd_seconds"])

    def test_05_idw_spatial_interpolation(self):
        idw = IDWInterpolationEngine(power=2.0)
        samples = [
            {"x": 100, "y": 100, "rssi": -40},
            {"x": 700, "y": 400, "rssi": -85}
        ]
        grid = idw.interpolate_grid(samples, grid_width=10, grid_height=10, bounds=(800, 480))
        self.assertEqual(len(grid), 10)
        self.assertEqual(len(grid[0]), 10)

    def test_06_multi_ap_roaming_simulator(self):
        sim = MultiAPRoamingSimulator(reference_rssi=-35.0, path_loss_exponent=2.8)
        aps = [
            {"id": "AP1", "name": "AP 1", "x": 100, "y": 100},
            {"id": "AP2", "name": "AP 2", "x": 700, "y": 400}
        ]
        # Client closer to AP1
        res = sim.simulate_environment(aps, {"x": 120, "y": 110})
        self.assertEqual(res["connected_ap"], "AP1")

    def test_07_database_and_csv_export(self):
        sample_data = {
            "ssid": "Academic_WLAN",
            "bssid": "11:22:33:44:55:66",
            "raw_rssi": -55.0,
            "kalman_rssi": -54.5,
            "sma_rssi": -54.8,
            "estimated_distance": 1.9,
            "rating": "Excellent",
            "channel": 36,
            "is_critical": False,
            "is_simulated": True
        }
        db.log_telemetry(sample_data)
        csv_str = db.export_csv_string()
        self.assertIn("Academic_WLAN", csv_str)

    def test_08_flask_rest_api_advanced_routes(self):
        tester = app.test_client(self)

        # GET /api/telemetry
        r1 = tester.get("/api/telemetry")
        self.assertEqual(r1.status_code, 200)
        data1 = json.loads(r1.data)
        self.assertIn("shannon_capacity_mbps", data1)
        self.assertIn("anomaly", data1)
        self.assertIn("trend", data1)

        # POST /api/heatmap/idw
        r2 = tester.post("/api/heatmap/idw", json={"samples": [{"x": 100, "y": 100, "rssi": -45}]})
        self.assertEqual(r2.status_code, 200)

        # POST /api/multi-ap/simulate
        r3 = tester.post("/api/multi-ap/simulate", json={"access_points": [{"id": "AP1", "x": 100, "y": 100}], "client_position": {"x": 110, "y": 110}})
        self.assertEqual(r3.status_code, 200)

        # GET /api/report/html
        r4 = tester.get("/api/report/html")
        self.assertEqual(r4.status_code, 200)
        self.assertIn("Audit Report", r4.data.decode("utf-8"))

if __name__ == "__main__":
    unittest.main()
