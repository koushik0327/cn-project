"""
Advanced Spatial Heatmap & Multi-AP Roaming Engine
Provides Inverse Distance Weighting (IDW) spatial interpolation
and Multi-AP coverage superposition simulation.
"""

import math

class IDWInterpolationEngine:
    """
    Inverse Distance Weighting (IDW) Spatial Interpolation.
    Computes smooth spatial RSSI gradient surface u(x, y) from discrete sample points.
    Formula: u(x) = sum(w_i * u_i) / sum(w_i) where w_i = 1 / d(x, x_i)^p
    """
    def __init__(self, power=2.0):
        self.p = power

    def interpolate_grid(self, samples: list, grid_width=40, grid_height=24, bounds=(800, 480)) -> list:
        if not samples:
            return []

        w_max, h_max = bounds
        dx = w_max / grid_width
        dy = h_max / grid_height
        
        grid = []
        for j in range(grid_height):
            row = []
            cy = (j + 0.5) * dy
            for i in range(grid_width):
                cx = (i + 0.5) * dx
                
                # Check exact match with a sample
                exact_val = None
                weights_sum = 0.0
                weighted_val_sum = 0.0

                for s in samples:
                    dist = math.hypot(cx - s["x"], cy - s["y"])
                    if dist < 1.0:
                        exact_val = s["rssi"]
                        break
                    
                    w = 1.0 / (dist ** self.p)
                    weights_sum += w
                    weighted_val_sum += w * s["rssi"]

                if exact_val is not None:
                    interp_val = exact_val
                elif weights_sum > 0:
                    interp_val = weighted_val_sum / weights_sum
                else:
                    interp_val = -90.0

                row.append(round(interp_val, 1))
            grid.append(row)
        return grid


class MultiAPRoamingSimulator:
    """
    Simulates multi-AP wireless deployment, client handover roaming,
    and AP repositioning vectors to eliminate indoor dead zones.
    """
    def __init__(self, reference_rssi=-35.0, path_loss_exponent=2.8):
        self.rssi_0 = reference_rssi
        self.n = path_loss_exponent

    def calculate_ap_rssi(self, ap_x: float, ap_y: float, client_x: float, client_y: float) -> float:
        dist_px = math.hypot(client_x - ap_x, client_y - ap_y)
        # Convert pixels to meters (approx 40 px = 1 meter)
        dist_m = max(0.5, dist_px / 40.0)
        rssi = self.rssi_0 - (10.0 * self.n * math.log10(dist_m))
        return round(max(-98.0, min(-30.0, rssi)), 1)

    def simulate_environment(self, access_points: list, client_pos: dict) -> dict:
        """
        :param access_points: list of dicts [{"id": "AP1", "x": 150, "y": 120, "name": "Main Router"}, ...]
        :param client_pos: dict {"x": 400, "y": 250}
        """
        if not access_points:
            return {"connected_ap": None, "best_rssi": -99.0, "ap_signals": []}

        signals = []
        best_ap = None
        best_rssi = -999.0

        for ap in access_points:
            rssi = self.calculate_ap_rssi(ap["x"], ap["y"], client_pos["x"], client_pos["y"])
            signals.append({
                "ap_id": ap.get("id", ap.get("name")),
                "name": ap.get("name", "AP"),
                "rssi": rssi,
                "x": ap["x"],
                "y": ap["y"]
            })
            if rssi > best_rssi:
                best_rssi = rssi
                best_ap = ap.get("id", ap.get("name"))

        # Compute superposition RSSI = 10 * log10(sum(10^(RSSI_i / 10)))
        linear_power_sum = sum(math.pow(10, s["rssi"] / 10.0) for s in signals)
        combined_rssi = round(10.0 * math.log10(linear_power_sum), 1)

        # AP Placement Optimization Vector Recommendation
        # Calculate vector towards dead zone
        avg_ap_x = sum(ap["x"] for ap in access_points) / len(access_points)
        avg_ap_y = sum(ap["y"] for ap in access_points) / len(access_points)
        vector_x = round(client_pos["x"] - avg_ap_x, 1)
        vector_y = round(client_pos["y"] - avg_ap_y, 1)

        return {
            "connected_ap": best_ap,
            "best_rssi": best_rssi,
            "combined_rssi": combined_rssi,
            "ap_signals": signals,
            "optimization_recommendation": {
                "vector_dx": vector_x,
                "vector_dy": vector_y,
                "suggestion": f"Move closest AP by ({vector_x}px, {vector_y}px) to boost coverage in client zone."
            }
        }
