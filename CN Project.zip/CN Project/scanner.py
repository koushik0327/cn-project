"""
Live Wi-Fi Telemetry Scanner Engine
Supports native Windows (netsh), Linux (nmcli/iwconfig), macOS (airport).
Accurately detects real Wi-Fi network switching (SSID/BSSID) and Wi-Fi OFF/Disconnected states.
"""

import os
import platform
import re
import subprocess
import random
import time
import math

class WiFiScanner:
    def __init__(self, mode="auto"):
        """
        :param mode: 'auto' (detect hardware), 'hardware' (force OS API), 'simulated' (force generator)
        """
        self.os_type = platform.system().lower()
        self.mode = mode
        self.sim_distance_step = 0
        self.sim_ssid = "Campus_WLAN_5GHz"
        self.sim_bssid = "74:83:C2:9A:E1:10"
        self.sim_channel = 36
        self.sim_frequency = "5.180 GHz"

    def set_mode(self, mode: str):
        self.mode = mode

    def scan(self) -> dict:
        """
        Scans for Wi-Fi telemetry and returns accurate state dictionary.
        """
        if self.mode == "simulated":
            sim = self._generate_simulated_telemetry()
            sim["is_simulated"] = True
            return sim

        # Execute native hardware scanning
        telemetry = None
        if "windows" in self.os_type:
            telemetry = self._scan_windows()
        elif "linux" in self.os_type:
            telemetry = self._scan_linux()
        elif "darwin" in self.os_type:
            telemetry = self._scan_macos()

        if telemetry is not None:
            if telemetry.get("connected", False):
                telemetry["is_simulated"] = False
                return telemetry
            elif self.mode in ("hardware", "auto"):
                # Explicitly return Disconnected state when hardware is off or disconnected
                return {
                    "connected": False,
                    "ssid": "Wi-Fi Disconnected",
                    "bssid": "00:00:00:00:00:00",
                    "rssi": -100.0,
                    "signal_percent": 0,
                    "channel": 0,
                    "frequency": "N/A",
                    "radio_type": "N/A",
                    "rx_rate": "0 Mbps",
                    "tx_rate": "0 Mbps",
                    "noise_floor": -95.0,
                    "is_simulated": False
                }

        # Fallback to simulated mode ONLY if OS scanning is unsupported
        sim = self._generate_simulated_telemetry()
        sim["is_simulated"] = True
        return sim

    def _scan_windows(self) -> dict:
        try:
            cmd = ["netsh", "wlan", "show", "interfaces"]
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                creationflags=0x08000000 if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            stdout, _ = process.communicate(timeout=3)

            if not stdout or "there is no wireless interface" in stdout.lower():
                return {"connected": False}

            data = {}
            for line in stdout.splitlines():
                if ":" in line:
                    parts = line.split(":", 1)
                    key = parts[0].strip()
                    val = parts[1].strip()
                    data[key] = val

            state_val = data.get("State", "").lower()
            if state_val != "connected":
                return {"connected": False}

            ssid = data.get("SSID", "Connected Network")
            bssid = data.get("BSSID", "00:11:22:33:44:55")
            radio_type = data.get("Radio type", "802.11n")
            channel_str = data.get("Channel", "11").strip()
            channel = int(channel_str) if channel_str.isdigit() else 11
            rx_rate = data.get("Receive rate (Mbps)", "72.2")
            tx_rate = data.get("Transmit rate (Mbps)", "72.2")
            signal_pct_str = data.get("Signal", "70%").replace("%", "").strip()
            
            signal_pct = int(signal_pct_str) if signal_pct_str.isdigit() else 70

            # Convert Windows signal percentage (0-100%) to dBm
            # Formula: dBm = (Signal% / 2) - 100
            rssi_dbm = float((signal_pct / 2.0) - 100.0)
            freq = "5 GHz" if channel > 14 else "2.4 GHz"

            return {
                "connected": True,
                "ssid": ssid,
                "bssid": bssid,
                "rssi": round(rssi_dbm, 2),
                "signal_percent": signal_pct,
                "channel": channel,
                "frequency": freq,
                "radio_type": radio_type,
                "rx_rate": rx_rate,
                "tx_rate": tx_rate,
                "noise_floor": -95.0
            }
        except Exception:
            return {"connected": False}

    def _scan_linux(self) -> dict:
        try:
            cmd = ["nmcli", "-t", "-f", "ACTIVE,SSID,BSSID,SIGNAL,CHAN,FREQ", "dev", "wifi"]
            output = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, timeout=3).decode("utf-8")
            for line in output.splitlines():
                if line.startswith("yes"):
                    parts = line.split(":")
                    if len(parts) >= 6:
                        ssid = parts[1]
                        bssid = parts[2]
                        sig_pct = int(parts[3])
                        chan = int(parts[4])
                        freq = parts[5]
                        rssi_dbm = (sig_pct / 2.0) - 100.0
                        return {
                            "connected": True,
                            "ssid": ssid,
                            "bssid": bssid,
                            "rssi": round(rssi_dbm, 2),
                            "signal_percent": sig_pct,
                            "channel": chan,
                            "frequency": freq,
                            "radio_type": "802.11ac",
                            "rx_rate": "300 Mbps",
                            "tx_rate": "300 Mbps",
                            "noise_floor": -95.0
                        }
        except Exception:
            pass
        return {"connected": False}

    def _scan_macos(self) -> dict:
        try:
            airport_path = "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
            output = subprocess.check_output([airport_path, "-I"], stderr=subprocess.DEVNULL, timeout=3).decode("utf-8")
            data = {}
            for line in output.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    data[k.strip()] = v.strip()
            if "agrCtlRSSI" in data and data.get("state") == "running":
                rssi = float(data["agrCtlRSSI"])
                ssid = data.get("SSID", "Mac WiFi")
                bssid = data.get("BSSID", "00:00:00:00:00:00")
                channel = int(data.get("channel", "36").split(",")[0])
                pct = max(0, min(100, int(2 * (rssi + 100))))
                return {
                    "connected": True,
                    "ssid": ssid,
                    "bssid": bssid,
                    "rssi": round(rssi, 2),
                    "signal_percent": pct,
                    "channel": channel,
                    "frequency": "5 GHz" if channel > 14 else "2.4 GHz",
                    "radio_type": "802.11ax",
                    "rx_rate": "400 Mbps",
                    "tx_rate": "400 Mbps",
                    "noise_floor": float(data.get("agrCtlNoise", -95.0))
                }
        except Exception:
            pass
        return {"connected": False}

    def _generate_simulated_telemetry(self) -> dict:
        self.sim_distance_step += 0.05
        base_rssi = -55.0 - (12.0 * math.sin(self.sim_distance_step / 4.0))
        noise = random.gauss(0.0, 1.8)
        fading_dip = -15.0 if random.random() < 0.05 else 0.0

        current_rssi = max(-98.0, min(-32.0, base_rssi + noise + fading_dip))
        signal_pct = max(0, min(100, int(2 * (current_rssi + 100))))

        return {
            "connected": True,
            "ssid": self.sim_ssid,
            "bssid": self.sim_bssid,
            "rssi": round(current_rssi, 2),
            "signal_percent": signal_pct,
            "channel": self.sim_channel,
            "frequency": self.sim_frequency,
            "radio_type": "802.11ax (Wi-Fi 6)",
            "rx_rate": f"{random.randint(120, 300)} Mbps",
            "tx_rate": f"{random.randint(100, 270)} Mbps",
            "noise_floor": -95.0
        }
